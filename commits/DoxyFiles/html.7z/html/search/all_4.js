var searchData=
[
  ['epc_37',['epc',['../classWaiting__Area.html#ae35218147d2e213a038ea8469b502396',1,'Waiting_Area']]],
  ['es_38',['es',['../classCpu.html#a974e1abc9d6c02aed31bdef24afafda9',1,'Cpu']]]
];
