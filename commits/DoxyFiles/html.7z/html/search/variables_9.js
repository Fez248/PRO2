var searchData=
[
  ['sera_180',['sera',['../classWaiting__Area.html#af8330a55e29939de1b46f0c16f002b12',1,'Waiting_Area']]]
];
