var searchData=
[
  ['find_5fbest_132',['find_best',['../classCluster.html#afaff5bd2847c24048b02705e9671da2e',1,'Cluster']]]
];
