var searchData=
[
  ['search_5fprocess_152',['search_process',['../classWaiting__Area.html#a22f3c475077f426d20e32e3d35a36c62',1,'Waiting_Area']]],
  ['space_5fleft_153',['space_left',['../classCpu.html#af62d530892364ea8530cab12c2ec1414',1,'Cpu']]]
];
