var searchData=
[
  ['max_175',['max',['../classCpu.html#aac2aadcb8ae5b0e5b337f1f886164e45',1,'Cpu']]],
  ['mema_176',['mema',['../classCpu.html#adebb3064aef3263f6e4084768059ae25',1,'Cpu']]],
  ['memo_177',['memo',['../classProcess.html#a21d2c162c236aa09d88f91bd025ce44b',1,'Process']]]
];
