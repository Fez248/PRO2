var searchData=
[
  ['wa_182',['wa',['../classWaiting__Area.html#ac4839348c5694ad72bd86ab5e96ca34a',1,'Waiting_Area']]]
];
