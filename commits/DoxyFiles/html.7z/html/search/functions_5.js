var searchData=
[
  ['get_5fmemory_133',['get_memory',['../classCpu.html#a99376a5e5ca2e8f98800be1a3fe80fae',1,'Cpu']]]
];
