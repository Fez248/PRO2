var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuwy",
  1: "cpw",
  2: "cpw",
  3: "abcefgimprsuwy",
  4: "cdefilmopstw",
  5: "acdmnos",
  6: "p",
  7: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

