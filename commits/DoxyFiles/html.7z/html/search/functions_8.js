var searchData=
[
  ['process_143',['Process',['../classProcess.html#a9f4553eac74c657bb451f390c17d6bea',1,'Process::Process()'],['../classProcess.html#a5711384fd578d025137787ade588bfc2',1,'Process::Process(int identity, int memmory, int delta, int direction)']]]
];
