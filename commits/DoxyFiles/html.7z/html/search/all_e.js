var searchData=
[
  ['simulation_20of_20a_20cluster_78',['Simulation of a cluster',['../index.html',1,'']]],
  ['search_5fprocess_79',['search_process',['../classWaiting__Area.html#a22f3c475077f426d20e32e3d35a36c62',1,'Waiting_Area']]],
  ['sera_80',['sera',['../classWaiting__Area.html#af8330a55e29939de1b46f0c16f002b12',1,'Waiting_Area']]],
  ['siu_81',['siu',['../Waiting__Area_8cc.html#a9f04e21438b8bb656e9ddd253952cbb0',1,'Waiting_Area.cc']]],
  ['siu_5fct_82',['siu_ct',['../Waiting__Area_8cc.html#a57490da531374d2f7dedaf4f53b0c8b0',1,'Waiting_Area.cc']]],
  ['siu_5fit_83',['siu_it',['../Waiting__Area_8cc.html#a31bb8ebe283c7d5565da749a9e5527f3',1,'Waiting_Area.cc']]],
  ['space_5fleft_84',['space_left',['../classCpu.html#af62d530892364ea8530cab12c2ec1414',1,'Cpu']]]
];
