var searchData=
[
  ['dir_169',['dir',['../classProcess.html#a859e26edf3265d40a42666d160b4a9c4',1,'Process']]],
  ['diro_170',['diro',['../classCpu.html#aa279093f84e550b4453addec33669709',1,'Cpu']]]
];
