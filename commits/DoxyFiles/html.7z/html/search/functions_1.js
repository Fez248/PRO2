var searchData=
[
  ['bp_123',['bp',['../classWaiting__Area.html#a4cadefb192f4184ca984e2d33786edca',1,'Waiting_Area']]],
  ['bpp_124',['bpp',['../classCluster.html#aced7cf64f11e80c668d164300f91d49a',1,'Cluster']]]
];
